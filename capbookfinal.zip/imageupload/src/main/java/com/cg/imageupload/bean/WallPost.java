package com.cg.imageupload.bean;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "wallposts")

public class WallPost {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)

	private int id;
	@Column
	@Lob
	private byte[] data;
	
	
	
@Column
	
	private String commentsbox;
//		@Temporal(TemporalType.DATE)
//
//		private Timestamp Time;
//	
//	@Autowired
//	@Temporal(TemporalType.DATE)
//	@DateTimeFormat(style = "yyyy-MM-dd")
//	@NotNull()
//	private Date date;

	


//	@Temporal(TemporalType.TIME)
//	@DateTimeFormat(style = "hh:mm")
//	@NotNull()
//	private Date time;

	public WallPost() { }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

	public String getCommentsbox() {
		return commentsbox;
	}

	public void setCommentsbox(String commentsbox) {
		this.commentsbox = commentsbox;
	}

	




	@Override
	public String toString() {
		return "WallPost [id=" + id + ", data=" + Arrays.toString(data) + "]";
	}

	

}
