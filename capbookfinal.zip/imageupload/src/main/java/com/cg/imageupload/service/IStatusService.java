package com.cg.imageupload.service;

import java.util.List;

import com.cg.imageupload.bean.Status;

public interface IStatusService {

	public List<Status> getAll();

	public Status addStatus(Status status);

	public Status get(int id);

	public void delete(int id);

	public Status update(Status status);

}
