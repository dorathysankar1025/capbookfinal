package com.cg.imageupload.service;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.multipart.MultipartFile;

import com.cg.imageupload.bean.Status;
import com.cg.imageupload.bean.WallPost;

public interface IFileuploadService {

	public WallPost createImage(MultipartFile file,WallPost wallpost) throws IOException ;

	public void delete(int id);

	public WallPost update (WallPost wallpost);

	public List<WallPost> getAlll();

	
	
		
	
}
