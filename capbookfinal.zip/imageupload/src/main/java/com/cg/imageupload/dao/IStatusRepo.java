package com.cg.imageupload.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.imageupload.bean.Status;

public interface IStatusRepo extends JpaRepository<Status, Integer> {

}
