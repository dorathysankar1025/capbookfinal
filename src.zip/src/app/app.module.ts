import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StatusupdateComponent } from './statusupdate/statusupdate.component';
import { HomeComponent } from './home/home.component';
import { CreatewallpostComponent } from './createwallpost/createwallpost.component';
import { ShowComponent } from './show/show.component';
import { ShowstatusComponent } from './showstatus/showstatus.component';
import { CommentComponent } from './comment/comment.component';
import { CommentwallpostComponent } from './commentwallpost/commentwallpost.component';

@NgModule({
  declarations: [
    AppComponent,
    StatusupdateComponent,
    HomeComponent,
    CreatewallpostComponent,
    ShowComponent,
    ShowstatusComponent,
    CommentComponent,
    CommentwallpostComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
