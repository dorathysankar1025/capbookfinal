import { Component, OnInit } from '@angular/core';
import { StatusService } from '../status.service';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {
  
Wallpost;
  constructor(private ms:StatusService) {
    ms.getAll().subscribe((res) => this.Wallpost=res)
   }
   removePost(id){
    this.ms.remove(id).subscribe(()=> {
    alert('deleted...')
    history.go();
    
    }
    )
    }
  ngOnInit() {
  }

}
