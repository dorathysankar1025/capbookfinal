import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class StatusService {

  constructor(private http:HttpClient) { }
public add(Status)
{
 //let opt = new HttpHeaders({'Content-Type':'image/jpeg'});
 return this.http.post('http://localhost:9085/add',Status);//,{headers:opt});
}
public getAll(){
  return this.http.get('http://localhost:9085/status');
  }
public remove(id)
  {
    return this.http.delete('http://localhost:9085/delete'+'/'+id);
  }
 public postComment(Status){
    let opt =new HttpHeaders({'Content-Type':'application/json'});
    return this.http.put("http://localhost:9085/status"+'/'+Status.id,Status,{headers:opt});
  }
 public  postCommentWallpost(Wallpost){
    let opt =new HttpHeaders({'Content-Type':'application/json'});
    return this.http.put("http://localhost:9085/wallpost"+'/'+Wallpost.id,Wallpost,{headers:opt});
  }
  public addWallPost(Wallpost){
   
    let opt =new HttpHeaders({'Content-Type':'application/json'});
    return this.http.post('http://localhost:9085/upload',Wallpost,{headers:opt});
  }
}
