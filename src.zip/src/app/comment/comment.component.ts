import { Component, OnInit } from '@angular/core';
import { StatusService } from '../status.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-comment',
  templateUrl: './comment.component.html',
  styleUrls: ['./comment.component.css']
})
export class CommentComponent implements OnInit {
  Status={
   id:'',
    comment:''
  };
    constructor(private ms:StatusService,private routes:Router) {
      this.Status=history.state.Status;
    }



    

  ngOnInit() {
  }
  postComment(){
    this.ms.postComment(this.Status).subscribe(()=>{
      alert('commented')
      this.routes.navigate(['showstatus'])})
    }
   
    }
    

