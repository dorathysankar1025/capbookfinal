import { Component, OnInit } from '@angular/core';
import { StatusService } from '../status.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-statusupdate',
  templateUrl: './statusupdate.component.html',
  styleUrls: ['./statusupdate.component.css']
})
export class StatusupdateComponent implements OnInit {

  constructor(private ms:StatusService,private router:Router ) {}
Status={
  id:'',
  message:'',
  image:'',
  comment:''
}
  
  addPost(){
    this.ms.add(this.Status).subscribe(()=> {
    alert('addedd...')
    this.router.navigate(['showstatus'])
    }
    )
    }

  ngOnInit() {
  }

}
