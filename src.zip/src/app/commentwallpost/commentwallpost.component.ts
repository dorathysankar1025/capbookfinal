import { Component, OnInit } from '@angular/core';
import { StatusService } from '../status.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-commentwallpost',
  templateUrl: './commentwallpost.component.html',
  styleUrls: ['./commentwallpost.component.css']
})
export class CommentwallpostComponent implements OnInit {

  
  Wallpost={ 
    id:'',
    image:'',
    comment:''
  };
    constructor(private ms:StatusService,private routes:Router) {
      this.Wallpost=history.state.Wallpost;
    }

    
  ngOnInit() {
  }
  postCommentWallpost(){
    this.ms.postCommentWallpost(this.Wallpost).subscribe(()=>{
    alert('commented')
      this.routes.navigate(['show'])})
    }

}
