import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommentwallpostComponent } from './commentwallpost.component';

describe('CommentwallpostComponent', () => {
  let component: CommentwallpostComponent;
  let fixture: ComponentFixture<CommentwallpostComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommentwallpostComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommentwallpostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
