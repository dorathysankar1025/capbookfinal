import { Component, OnInit } from '@angular/core';
import { StatusService } from '../status.service';

@Component({
  selector: 'app-showstatus',
  templateUrl: './showstatus.component.html',
  styleUrls: ['./showstatus.component.css']
})
export class ShowstatusComponent implements OnInit {
Status;

constructor(private ms:StatusService) {
  ms.getAll().subscribe((res) => this.Status=res)
 }
 removeStatus(sid){
  this.ms.remove(sid).subscribe(()=> {
  alert('deleted...')
  history.go();
  
  }
  )
  }


ngOnInit() {
}

}

 
