import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatewallpostComponent } from './createwallpost.component';

describe('CreatewallpostComponent', () => {
  let component: CreatewallpostComponent;
  let fixture: ComponentFixture<CreatewallpostComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreatewallpostComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatewallpostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
