import { Component, OnInit } from '@angular/core';
import {StatusService} from  '../status.service';
import { Router } from '@angular/router';
import { mergeAnalyzedFiles } from '@angular/compiler';
import { JsonpClientBackend } from '@angular/common/http';
@Component({
  selector: 'app-createwallpost',
  templateUrl: './createwallpost.component.html',
  styleUrls: ['./createwallpost.component.css']
})
export class CreatewallpostComponent implements OnInit {
  imageUrl:String="/assets/images/profile.jpeg";
  fileToUpload:File=null;
  constructor(private ms:StatusService,private router:Router) { }
  Wallpost={
    id:'',
    image:'',
    comment:''
  }
    
    uploadWallPost(){
      this.ms.add(this.Wallpost).subscribe(()=> {
      alert('addedd...')
      this.router.navigate(['show'])
      }
      )
      }

  ngOnInit() {
  }
  handleFileInput(file:FileList)
  {
    this.fileToUpload=file.item(0);
    var reader=new FileReader();
    reader.onload=(event:any)=>{
      this.imageUrl=event.target.result;
      
    }
    reader.readAsDataURL(this.fileToUpload);
  }

}
