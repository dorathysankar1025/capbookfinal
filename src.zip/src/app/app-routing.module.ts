import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StatusupdateComponent } from './statusupdate/statusupdate.component';
import { HomeComponent } from './home/home.component';
import { CreatewallpostComponent } from './createwallpost/createwallpost.component';
import { ShowComponent } from './show/show.component';
import { ShowstatusComponent } from './showstatus/showstatus.component';
import { CommentComponent } from './comment/comment.component';
import { CommentwallpostComponent } from './commentwallpost/commentwallpost.component';


const routes: Routes = [
  
  {path:'',component:HomeComponent},
    {path:'statusupdate',component:StatusupdateComponent},
    {path:'createwallpost',component:CreatewallpostComponent},
    {path:'show',component:ShowComponent},
    {path:'showstatus',component:ShowstatusComponent},
    {path:'comment',component:CommentComponent},
    {path:'commentwallpost',component:CommentwallpostComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
